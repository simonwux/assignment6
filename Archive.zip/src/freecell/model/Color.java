package freecell.model;

public enum Color {
  RED, BLACK
}
